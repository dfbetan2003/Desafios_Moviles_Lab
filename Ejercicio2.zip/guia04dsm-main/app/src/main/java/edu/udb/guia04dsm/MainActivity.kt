package edu.udb.guia04dsm

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etName = findViewById<EditText>(R.id.etName)
        val etSalary = findViewById<EditText>(R.id.etSalary)
        val btnCalculate = findViewById<Button>(R.id.btnCalculate)
        val tvResult = findViewById<TextView>(R.id.tvResult)

        btnCalculate.setOnClickListener {
            val name = etName.text.toString()
            val salary = etSalary.text.toString().toDoubleOrNull()

            if (salary != null) {
                val afp = salary * 0.0725
                val isss = salary * 0.03
                val renta = calculateRenta(salary)
                val netSalary = salary - afp - isss - renta

                val result = """
                    Nombre: $name
                    Salario Base: $salary
                    AFP (7.25%): $afp
                    ISSS (3%): $isss
                    Renta: $renta
                    Salario Neto: $netSalary
                """.trimIndent()

                tvResult.text = result
            } else {
                tvResult.text = "Por favor, ingrese un salario válido."
            }
        }
    }

    private fun calculateRenta(salary: Double): Double {
        return when {
            salary <= 472.00 -> 0.0
            salary <= 895.24 -> (salary - 472.00) * 0.10 + 17.67
            salary <= 2038.10 -> (salary - 895.24) * 0.20 + 60.00
            else -> (salary - 2038.10) * 0.30 + 288.57
        }
    }
}